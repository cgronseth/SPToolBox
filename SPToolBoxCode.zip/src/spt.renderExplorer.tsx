import * as React from "react";
import * as ReactDOM from "react-dom";

import { Explorer } from "./components/spt.explorer";

ReactDOM.render(
    <Explorer />, document.getElementById("spt.explorer")
);