import * as React from "react";
import * as ReactDOM from "react-dom";

import { Menu } from "./components/spt.menu";

ReactDOM.render(
    <Menu />, document.getElementById("spt.menu")
);